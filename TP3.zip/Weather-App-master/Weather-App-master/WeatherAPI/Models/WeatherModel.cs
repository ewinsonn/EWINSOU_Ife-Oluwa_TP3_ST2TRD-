namespace WeatherAPI
{
    public class WeatherModel
    {
        public string Main { get; set; }
        public string Description { get; set; }
    }
}