namespace WeatherAPI
{
    public class CloudsModel
    {
        public int All { get; set; }
    }
}