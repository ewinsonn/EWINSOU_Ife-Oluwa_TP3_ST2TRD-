namespace WeatherAPI
{
    public class WindModel
    {
        public double Speed { get; set; }
        public double Deg { get; set; }
        public double Gust { get; set; }
    }
}