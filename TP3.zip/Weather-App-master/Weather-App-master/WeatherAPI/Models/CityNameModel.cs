namespace WeatherAPI
{
    public class CityNameModel
    {
        public string Name { get; set; }
    }
}