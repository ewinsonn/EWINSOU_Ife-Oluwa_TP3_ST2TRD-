# Weather-App

Weather application that uses the <a href="https://openweathermap.org/">OpenWeatherMap</a> current weather API to display current weather data for any of the 1000 largest cities in the United States.

![alt text](https://github.com/JustinTracy/Weather-App/blob/master/Display/Images/Screenshot%20(138).png?raw=true)<br><br>
![alt text](https://github.com/JustinTracy/Weather-App/blob/master/Display/Images/Screenshot%20(139).png?raw=true)<br><br>
![alt text](https://github.com/JustinTracy/Weather-App/blob/master/Display/Images/Screenshot%20(140).png?raw=true)

