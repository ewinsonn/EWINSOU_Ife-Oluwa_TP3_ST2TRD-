using System.Windows.Presentation;

namespace Controls
{
    public class WeatherButton : Button
    {
        
    }
}